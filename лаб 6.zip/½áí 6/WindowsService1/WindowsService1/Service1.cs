﻿using System;
using System.ComponentModel;
using System.ServiceProcess;
using System.Configuration.Install;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WindowsService1
{
    [RunInstaller(true)]
    public class MyServiceInstaller : Installer
    {
        public MyServiceInstaller()
        {
            var processInstaller = new ServiceProcessInstaller();
            var serviceInstaller = new ServiceInstaller();

            //set the privileges
            processInstaller.Account = ServiceAccount.LocalSystem;

            serviceInstaller.DisplayName = "WindowsService";
            serviceInstaller.StartType = ServiceStartMode.Manual;

            //must be the same as what was set in Program's constructor
            serviceInstaller.ServiceName = "WindowsService";

            this.Installers.Add(processInstaller);
            this.Installers.Add(serviceInstaller);
        }
    }

    public partial class Service1 : ServiceBase
    {
        private FileSystemWatcher watcher;
        public Service1()
        {
            InitializeComponent();

            watcher = new FileSystemWatcher(@"C:\Users\aleks\Desktop\lab6_ser");
            watcher.Created += OnChanged;
        }

        protected override void OnStart(string[] args)
        {
            watcher.EnableRaisingEvents = true;
        }

        protected override void OnStop()
        {
            watcher.EnableRaisingEvents = false;
        }
        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                if ((File.GetAttributes(e.FullPath) & FileAttributes.Directory) == FileAttributes.Directory)
                {
                    if (!Directory.EnumerateFileSystemEntries(e.FullPath).Any())
                    {
                        Directory.Delete(e.FullPath);
                    }
                }
                else
                {
                    File.Delete(e.FullPath);
                }

                using (StreamWriter sw = File.AppendText(@"C:\Users\aleks\Desktop\log.txt"))
                {
                    sw.WriteLine($"{DateTime.Now}: Deleted {e.FullPath}");
                }
            }
            catch (IOException)
            {
                Task.Delay(1000).ContinueWith(t => OnChanged(sender, e));
            }
            catch (UnauthorizedAccessException ex)
            {
                using (StreamWriter sw = File.AppendText(@"C:\Users\aleks\Desktop\log.txt"))
                {
                    sw.WriteLine($"{DateTime.Now}: Access denied - {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                using (StreamWriter sw = File.AppendText(@"C:\Users\aleks\Desktop\log.txt"))
                {
                    sw.WriteLine($"{DateTime.Now}: Exception occurred - {ex.Message}");
                }
            }
        }

    }
}