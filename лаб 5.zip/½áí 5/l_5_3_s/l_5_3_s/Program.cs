﻿using System;
using System.Diagnostics;
using System.IO.Pipes;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace l_5_3_s
{
    public class Server
    {
        const string EXE_PATH = @"C:\Users\aleks\source\repos\l_5_3_c\l_5_3_c\bin\Debug\net8.0\l_5_3_c.exe";
        Thread[] serverThreads;
        int numClients;
        byte[] byteMessage;
        public Server(int numClients)
        {
            this.numClients = numClients;
            serverThreads = new Thread[numClients];
        }
        public void Start(string message, int repeatCount)
        {
            byteMessage = Encoding.ASCII.GetBytes(message + "|" + repeatCount.ToString());
            for (int i = 0; i < numClients; i++)
            {
                serverThreads[i] = new Thread(ServerThread);
                serverThreads[i].Start();
            }
        }
        private void ServerThread()
        {
            try
            {
                int threadID = Thread.CurrentThread.ManagedThreadId;
                NamedPipeServerStream serverPipe = new NamedPipeServerStream("pipe" + threadID, PipeDirection.InOut, 1);
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = EXE_PATH,
                    Arguments = threadID.ToString()
                };
                Process client = Process.Start(info)!;
                serverPipe.WaitForConnection();
                serverPipe.Write(byteMessage, 0, byteMessage.Length);
                serverPipe.WaitForPipeDrain();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Process Server.");
            Console.Write("Count of processes: ");
            int count = Convert.ToInt32(Console.ReadLine());
            Server server = new Server(count);
            Console.Write("Enter message: ");
            string message = Console.ReadLine()!;
            int repeatCount = 1;
            server.Start(message, repeatCount);
            Console.ReadKey();
        }
    }
}
