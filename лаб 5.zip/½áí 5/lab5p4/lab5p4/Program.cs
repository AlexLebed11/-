static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        Thread serverThread = new Thread(() => Application.Run(new ServerForm()));
        serverThread.Start();

        Thread clientThread = new Thread(() => Application.Run(new ClientForm()));
        clientThread.Start();
    }
}