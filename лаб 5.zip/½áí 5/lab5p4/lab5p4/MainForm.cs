﻿using System;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Windows.Forms;
using System.Threading.Tasks;

public class ServerForm : Form
{
    private System.Windows.Forms.Timer timer;
    private Panel panel;
    private NamedPipeServerStream pipeServer;

    public ServerForm()
    {
        timer = new System.Windows.Forms.Timer();
        panel = new Panel { Dock = DockStyle.Fill };

        Controls.Add(panel);
        timer.Tick += OnTick!;
        timer.Interval = 1000;
        timer.Start();

        pipeServer = new NamedPipeServerStream("testpipe", PipeDirection.Out);
        Task.Run(() => pipeServer.WaitForConnection());
    }

    private void OnTick(object sender, EventArgs e)
    {
        var random = new Random();
        var color = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
        panel.BackColor = color;

        var colorString = $"{color.R},{color.G},{color.B}";
        var sw = new StreamWriter(pipeServer);
        sw.AutoFlush = true;
        sw.WriteLine(colorString);
    }
}

public class ClientForm : Form
{
    private Label label;
    private NamedPipeClientStream pipeClient;

    public ClientForm()
    {
        label = new Label { Dock = DockStyle.Fill, AutoSize = false, TextAlign = ContentAlignment.MiddleCenter };

        Controls.Add(label);

        pipeClient = new NamedPipeClientStream(".", "testpipe", PipeDirection.In);
        pipeClient.Connect();

        _ = Task.Run(() =>
        {
            var sr = new StreamReader(pipeClient);
            while (true)
            {
                var colorString = sr.ReadLine();
                var rgb = colorString.Split(',');
                var color = Color.FromArgb(int.Parse(rgb[0]), int.Parse(rgb[1]), int.Parse(rgb[2]));
                UpdateColor(color);
            }
        });
    }

    private void UpdateColor(Color color)
    {
        if (label.InvokeRequired)
        {
            label.Invoke(new Action(() => label.Text = $"R: {color.R}, G: {color.G}, B: {color.B}"));
        }
        else
        {
            label.Text = $"R: {color.R}, G: {color.G}, B: {color.B}";
        }
    }
}
