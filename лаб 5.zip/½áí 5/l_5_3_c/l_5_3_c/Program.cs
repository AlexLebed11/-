﻿using System;
using System.Diagnostics;
using System.IO.Pipes;
using System.Security.Principal;
using System.Text;

namespace l_5_3_c
{
    public class Client
    {
        NamedPipeClientStream clientPipe;
        int clientID;
        public Client(string serverID)
        {
            clientID = Process.GetCurrentProcess().Id;
            clientPipe = new NamedPipeClientStream(".", "pipe" + serverID, PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.None);
        }
        public void Start()
        {
            try
            {
                clientPipe.Connect();
                byte[] inBytes = new byte[100];
                clientPipe.Read(inBytes, 0, 100);
                string inStr = Encoding.ASCII.GetString(inBytes);
                string[] parts = inStr.Split('|');
                string message = parts[0];
                int repeatCount = int.Parse(parts[1]);
                for (int i = 0; i < repeatCount; i++)
                {
                    Console.WriteLine("\t Received from server: {0}", message);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("\t Error: " + ex.Message);
                return;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\t Process client.");
            Client client = new Client(args[0]);
            client.Start();
            Console.ReadKey();
        }
    }
}
