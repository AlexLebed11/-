﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Text;
using System.Threading;


//namespace l_5_1_s
//{
//    class Program
//    {
//        static Process client;
//        const string EXE_PATH = @"C:\Users\aleks\source\repos\step lab5(1)\step lab5(1)\bin\Debug\net8.0\step lab5(1)";
//        static void Main(string[] args)
//        {
//            Console.WriteLine("\tPROCESS SERVER.");

//            using (AnonymousPipeServerStream pipeServer = new AnonymousPipeServerStream(PipeDirection.In, HandleInheritability.Inheritable))
//            {
//                StartClient(pipeServer.GetClientHandleAsString());
//                pipeServer.DisposeLocalCopyOfClientHandle();
//                using (StreamReader sr = new StreamReader(pipeServer))
//                {
//                    string temp;
//                    // Wait for 'sync message' from the client.
//                    do
//                    {
//                        Console.WriteLine("\t[SERVER] Wait for sync...");

//                        temp = sr.ReadLine()!;
//                        if (temp == null)
//                        {
//                            break;
//                        }
//                    }while (!temp.StartsWith("\tSYNC"));

//                    Console.WriteLine("\t[SERVER] Client has connected");
//                    do
//                    {
//                        temp = sr.ReadLine()!;
//                        Console.WriteLine(string.IsNullOrEmpty(temp) ? "\t[SERVER] No response from client" :

//                            "\t[SERVER] Received: " + temp);
//                    }while (!client.HasExited);

//                }
//                client.Close();
//                Console.WriteLine("\t[SERVER] Client quit.Server terminating."); 
//                Console.ReadKey();
//            }
//        }
//        static void StartClient(string clientHandle)
//        {
//            ProcessStartInfo info = new ProcessStartInfo(EXE_PATH);
//            info.Arguments = clientHandle;
//            info.UseShellExecute = false;
//            client = Process.Start(info)!;
//        }

//    }
//}

//namespace l_5_2_s
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Process Server.");
//            NamedPipeServerStream serverPipe = new NamedPipeServerStream("myPipe", PipeDirection.InOut, 1);
//            Console.WriteLine("Waiting for client...");
//            serverPipe.WaitForConnection();
//            Console.WriteLine("Client has connected...");
//            Console.WriteLine("Press any key to continue");
//            Console.ReadKey();

//            try
//            {
//                //send
//                byte sendData = 48;
//                serverPipe.WriteByte(sendData);
//                Console.WriteLine("Sended: " + sendData);
//                //receive
//                int dataReceive = serverPipe.ReadByte();
//                Console.WriteLine("Received: " + dataReceive);
//                serverPipe.Close();
//            }
//            catch (IOException ex)
//            {
//                Console.WriteLine("Error: " + ex.Message);
//            }

//            Console.ReadKey();
//        }
//    }
//}



//namespace l_5_2_c
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Process client.");

//            //connect
//            NamedPipeClientStream pipe = new NamedPipeClientStream(".", "myPipe", PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.None);
//            pipe.Connect();
//            Console.WriteLine("Connected with server");
//            //read data

//            int dataReceive = pipe.ReadByte();
//            Console.WriteLine("Client receive: " + dataReceive.ToString());
//            //write data
//            byte dataSend = 24;
//            pipe.WriteByte(dataSend);
//            Console.WriteLine("Client send: " + dataSend.ToString());
//            //close pipe
//            pipe.Close();
//            Console.ReadKey();
//        }
//    }
//}

namespace l_5_3_s
{
    public class Server
    {
        const string EXE_PATH = @"C:\Users\aleks\source\repos\steplab5(3)\steplab5(3)\bin\Debug\net8.0\steplab5(3)";
        Thread[] serverThreads;
        int numClients;
        byte[] byteMessage;
        public Server(int numClients)
        {
            this.numClients = numClients;
            serverThreads = new Thread[numClients];
        }
        public void Start(string message)
        {
            byteMessage = Encoding.ASCII.GetBytes(message);
            for (int i = 0; i < numClients; i++)
            {
                serverThreads[i] = new Thread(ServerThread);
                serverThreads[i].Start();
            }
        }
        private void ServerThread()
        {
            try
            {
                int threadID = Thread.CurrentThread.ManagedThreadId;
                NamedPipeServerStream serverPipe = new NamedPipeServerStream("pipe" + threadID, PipeDirection.InOut, 1);
                //client creating
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = EXE_PATH,
                    Arguments = threadID.ToString()
                };
                Process client = Process.Start(info)!;
                Console.WriteLine("[{0}] Waiting for client...", threadID);
                serverPipe.WaitForConnection();

                //sending
                serverPipe.Write(byteMessage, 0, byteMessage.Length);

                // чекаємо поки клієнт отримає повідомлення
                serverPipe.WaitForPipeDrain();
                Console.WriteLine("[{0}] Client has received the message", threadID);
                //receive
                byte[] reqBytes = new byte[100];
                serverPipe.Read(reqBytes, 0, 100);
                Console.WriteLine("[{0}] Got request: {1}", threadID, Encoding.ASCII.GetString(reqBytes));
                client.WaitForExit();
                Console.WriteLine("[{0}] Client has exited", threadID);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Process Server.");
            Console.Write("Count of processes: ");
            int count = Convert.ToInt32(Console.ReadLine());

            //create server
            Server server = new Server(count);
            Console.Write("Enter message: ");
            //starting server
            server.Start(Console.ReadLine()!);
            Console.ReadKey();
        }
    }
}
