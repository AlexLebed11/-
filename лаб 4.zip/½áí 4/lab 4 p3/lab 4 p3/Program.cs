﻿using System;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Threading;

namespace l_4_3_a
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MemoryMappedFile mmf = MemoryMappedFile.CreateNew("procfile", 10000))
            {
                bool mutexCreated;
                Console.WriteLine("\t\tПроцес А.");
                Console.WriteLine("Створюється м'ютекс.");
                Mutex mutex = new Mutex(true, "testmapmutex", out mutexCreated);

                Console.WriteLine("Непостiйний зiставлений у пам’ятi файл.");
           

                using (MemoryMappedViewStream stream = mmf.CreateViewStream())
                {
                    BinaryWriter writer = new BinaryWriter(stream);
                    Console.WriteLine("Запис даних.");
                    writer.Write("Hello");
                }

                mutex.ReleaseMutex();
                Process procB = new Process();
                procB.StartInfo.FileName = @"C:\Users\aleks\source\repos\step1\step1\bin\Debug\net8.0\step1.exe";
                procB.Start();
                Console.WriteLine("Запуск процеса В. Для продовження натиснути ENTER.");
               
                Console.ReadLine();
                mutex.WaitOne();
                using (MemoryMappedViewStream stream = mmf.CreateViewStream())
                {
                    stream.Position = 0; 
                    StreamReader reader = new StreamReader(stream);
                    Console.WriteLine("Процес A передав: {0}", reader.ReadLine());
                    Console.WriteLine("Процес B передав: {0}", reader.ReadLine());
                }
                mutex.ReleaseMutex();
                Console.ReadKey();
            }
        }
    }
}