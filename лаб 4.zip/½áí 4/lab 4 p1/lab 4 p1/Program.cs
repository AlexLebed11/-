﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Threading;

//namespace l_4_1
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int[] mas = new int[] { 1, 32, 45, 11, -5, 0, 78, 52 };
//            List<int> inputMas = new List<int>();
//            Console.WriteLine("Масив.");
//            for (int i = 0; i < mas.Length; i++)
//            {
//                Console.Write(mas[i] + " ");
//            }

//            Console.WriteLine("\n Зiставлений у пам’ятi файл з файлу на диску.");

//            using (MemoryMappedFile mnf = MemoryMappedFile.CreateFromFile("a1.dta", FileMode.OpenOrCreate, "file", 1))
//            {
//                using (MemoryMappedViewStream stream = mnf.CreateViewStream())
//                {
//                    BinaryWriter writer = new BinaryWriter(stream);
//                    foreach (int i in mas)
//                    {
//                        writer.Write(i);
//                    }
//                    writer.Close();
//                    Console.WriteLine("\n Файл на диску створений та закритий.");
//                }

//                using (MemoryMappedViewStream stream = mnf.CreateViewStream())
//                {
//                    BinaryReader reader = new BinaryReader(stream);
//                    for (int i = 0; i < mas.Length; i++)
//                    {
//                        inputMas.Add(reader.ReadInt32());
//                    }
//                }
//                foreach (int i in inputMas)
//                {
//                    Console.Write(i + " ");
//                }

//                Console.ReadKey();
//            }
//        }
//    }
//}

//namespace l_4_2
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int[] mas = new int[] { 1, 32, 45, 11, 0, 78, 52 };
//            List<int> inputMas = new List<int>();
//            Console.WriteLine("Масив.");
//            for (int i = 0; i < mas.Length; i++)
//            {
//                Console.Write(mas[i] + " ");
//            }

//            Console.WriteLine("\n Непостiйний зiставлений у пам’ятi файл.");

//            using (MemoryMappedFile mnf = MemoryMappedFile.CreateNew("n_file", 4096))
//            {
//                using (MemoryMappedViewStream stream = mnf.CreateViewStream())
//                {
//                    BinaryWriter writer = new BinaryWriter(stream);
//                    foreach (int i in mas)
//                    {
//                        writer.Write(i);
//                    }

//                    writer.Close();
//                }

//                using (MemoryMappedViewStream stream = mnf.CreateViewStream())
//                {
//                    BinaryReader reader = new BinaryReader(stream);
//                    for (int i = 0; i < mas.Length; i++)
//                    {
//                        inputMas.Add(reader.ReadInt32());
//                    }
//                }
//                foreach (int i in inputMas)
//                {
//                    Console.Write(i + " ");
//                }

//                Console.ReadKey();
//            }
//        }
//    }
//}


namespace l_4_3_a
{
    class Program
    {
        static void Main(string[] args)
        {
            using (MemoryMappedFile mmf = MemoryMappedFile.CreateNew("procfile", 10000))
            {
                bool mutexCreated;
                Console.WriteLine("\t\tПроцес А.");
                Console.WriteLine("Створюється м'ютекс.");
                Mutex mutex = new Mutex(true, "testmapmutex", out mutexCreated);

                Console.WriteLine("Непостiйний зiставлений у пам’ятi файл.");
           

                using (MemoryMappedViewStream stream = mmf.CreateViewStream())
                {
                    BinaryWriter writer = new BinaryWriter(stream);
                    Console.WriteLine("Запис даних.");
                    writer.Write(true);
                }
                mutex.ReleaseMutex();
                Process procB = new Process();
                procB.StartInfo.FileName = @"C:\Users\aleks\source\repos\step\step\bin\Debug\net8.0\step.exe";
                procB.Start();
                Console.WriteLine("Запуск процеса В. Для продовження натиснути ENTER.");
               
                Console.ReadLine();
                mutex.WaitOne();
                using (MemoryMappedViewStream stream = mmf.CreateViewStream())
                {
                    BinaryReader reader = new BinaryReader(stream);
                    Console.WriteLine("Процес A передав: {0}",
                   reader.ReadBoolean());
                    Console.WriteLine("Процес B передав: {0}",
                   reader.ReadBoolean());
                }

                mutex.ReleaseMutex();
                Console.ReadKey();
            }
        }
    }
}
